TOSHIBA e-STUDIO Series

     Copyright(c) 2003-2023 Toshiba Tec Corporation All Rights Reserved.
                     April 21, 2023

This product has the following restrictions and issues.  Please be sure to read this before using.

----------------------------------------------------------------------
<for Color Models>
        for UNIX/LINUX Filter                           Version 7.116.0.0
        for CUPS PPD                                    Version 7.116.0.0

<for Black and White Models>
        for UNIX/LINUX Filter                           Version 7.116.0.0
        for CUPS PPD                                    Version 7.116.0.0
----------------------------------------------------------------------

Issues
======

1. Unix/Linux Filter

- All stapling options are displayed even though some are unavailable.  For example, you can select "Portrait A4 Left Hand Side" stapling even when you are using A3.
As you cannot staple on the long edge of A3, your job will not be stapled.
However the job will get printed.

<e-STUDIO6550C Series/ e-STUDIO6570C Series>
- When you are using the MJ-1103 Finisher or MJ-1104 Saddle Stitch Finisher, copies cannot be stapled on Tray 1.

<e-STUDIO4540C Series / e-STUDIO456 Series>
- When you are using the MJ-1101 Finisher or MJ-1106 Saddle Stitch Finisher, copies cannot be stapled on Tray 1.

<e-STUDIO2550C Series / e-STUDIO5055C Series/ e-STUDIO457 Series>
- When you are using the MJ-1107 Finisher or MJ-1108 Saddle Stitch Finisher, copies cannot be stapled on Tray 1.


2. Banner Page
- Banner page will be output onto a tray that had been designated in RAW Jobs - Default Output Tray in TopAccess.

--------------------------------------------------------------------------------
Trademarks
--------------------------------------------------------------------------------

- IBM, AT and AIX are trademarks of International Business Machines Corporation.
- TopAccess is a trademark of Toshiba Tec Corporation.
- SUN, Java, and other trademarks and logos including Java are trademarks or registered trademarks of Sun Microsystems,Inc. in the United States and other countries.
- Other company names and product names in this manual are the trademarks of their respective companies.
